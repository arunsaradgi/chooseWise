import { ExperiencePipe } from './experience.pipe';

describe('ExperiencePipe', () => {
  it('create an instance', () => {
    const pipe = new ExperiencePipe();
    expect(pipe).toBeTruthy();
  });
});
