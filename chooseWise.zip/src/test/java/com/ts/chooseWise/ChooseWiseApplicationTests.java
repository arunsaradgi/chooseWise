package com.ts.chooseWise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChooseWiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
