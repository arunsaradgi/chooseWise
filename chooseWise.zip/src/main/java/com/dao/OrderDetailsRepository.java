package com.dao;

public interface OrderDetailsRepository {

}
