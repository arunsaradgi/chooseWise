package com.dao;

public interface ProductRepository {

}
