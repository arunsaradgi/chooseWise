package com.dao;

public interface OrdersRepository {

}
