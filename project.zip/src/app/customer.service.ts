import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  public userLogged:boolean;
  constructor(public httpClient: HttpClient,public router:Router) { 
    this.userLogged=false;
  }

  public setUserLoggedIn(): void{
    this.userLogged=true;
  }
  public setUserLoggedOut(): void{
    this.userLogged=false;
    this.router.navigate(["login"])
  }
  public getUserLogged():any{
    return this.userLogged;
  }
  getAllCustomers(): any {
    return this.httpClient.get('getAllCustomers');
  }

  getCustomerById(customerId: any): any {
    return this.httpClient.get('getCustomerById/' + customerId);
  }

  register(regForm: any): any {
    console.log(regForm);
    return this.httpClient.post("register/",regForm);
  }
  loginAuthentication(loginId: any,password :any):any{

    return this.httpClient.get('getCustomerByLoginId/' +loginId +'/'+ password);

  }
 
}
