import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  customers:any;
  constructor(public customerService:CustomerService) { }

  ngOnInit(): void {
  }

  registerUser(regForm: any) : void {
    console.log(regForm);
    this.customerService.register(regForm).subscribe((result: any) => console.log(result));
}
}
